<?php 
require "read.php";

if (isset($_POST['Add']))
	{
		$val_nama  = $_POST['input_nama'];
		$val_kelas = $_POST['input_kelas'];
		$val_id = $_POST['input_id'];
		$sql = "INSERT INTO table_crud (nama,kelas,id) VALUES ('$val_nama' , '$val_kelas' , '$val_id')";
		$execute = mysqli_query($koneksi , $sql);
	}

	 if ($execute)
	{
		header('Location:read.php');
	}

	else 
	{
		echo "FAILED TO ADD THE DATA";
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>CREATE PHP</title>
</head>
<body>
	<form action="?<?php $_SERVER['PHP_SELF'] ?>" method="POST">

	<h3>INSERT DATA </h3>

	<label>ID</label>
	<input type="text" name="input_id">
	<br>
	<br>


	<label>NAMA</label>
	<input type="text" name="input_nama">
	<br>
	<br>

	<label>KELAS</label>
	<input type="text" name="input_kelas">
	<br>
	<br>

	<input type="submit" name="Add" value="Add">
</form>

</body>
</html>