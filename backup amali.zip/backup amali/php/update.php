<?php
  
  require "koneksi.php";
  $id = $_GET['id'];
  $sql_read = "SELECT * FROM table_crud WHERE id= '$id'";
  $exe_read = mysqli_query($koneksi, $sql_read);
  $res_read = mysqli_fetch_assoc($exe_read);


  if(isset($_POST['update'])){
    $val_nama = $_POST['input_nama'];
    $val_kelas = $_POST['input_kelas'];
    $val_id = $_POST['input_id'];

    $sql = "UPDATE table_crud SET nama ='$val_nama', kelas = '$val_kelas' , id = '$val_id' WHERE id ='$id'";
    $execute = mysqli_query($koneksi, $sql);

    if ($execute)
    {
      header('Location:read.php');
    } 

    else 
    {
      echo "THE DATA IS NOT RECOGNIZED !"; 
    }

  }

?>

<!DOCTYPE html>
<html>
<head>
  <title>Update PHP</title>
</head>
<body>
  <form action="<?php $_SERVER['PHP_SELF']?>" method="POST">

    <h3>UPDATE YOUR DATA</h3>

    <label>ID</label>
    <input type="text" name="input_id">

    <br>
    <br>

    <label>NAME</label>
    <input type="text" name="input_nama">

    <br>
    <br>

    <label>CLASS</label>
    <input type="text" name="input_kelas">

    <br>
    <br>
    <input type="submit" name="update" value="Update">
  </form>
</body>
</html>