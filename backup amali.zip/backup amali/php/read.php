<?php 
require "koneksi.php";
$sql 	 = "SELECT * FROM table_crud";
$execute = mysqli_query($koneksi, $sql);

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>hello</title>
</head>
<body>
	<a href="create.php" style="text-align: center;">INSERT DATA</a>
	<table border="1" width="50%" align="center">
		<thead>
			<th>ID</th>
			<th>NAME</th>
			<th>CLASS</th>
			<th>CHOOSE</th>
		</thead>
		<?php while ($result = mysqli_fetch_assoc($execute)){ ?>
		<tr>
			<td align="center"><?= $result['id']?></td>
			<td align="center"><?= $result['nama']?></td>
			<td align="center"><?= $result['kelas']?></td>
			<td align="center"><a href="update.php?id=<?= $result['id']?>">update</a> | <a href="delete.php?id=<?= $result['id']?>">delete</a></td>
		</tr>
		<?php } ?>
	</table>

</body>
</html>