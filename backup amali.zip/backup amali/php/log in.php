<!DOCTYPE html>
<html>
<head>
	<title>login</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style>

	   body {
  			font-family: Arial, Helvetica, sans-serif;
  			background-color: black;
		 	}

	   	  * {
  			box-sizing: border-box;
		    }

 .container {
 			padding: 16px;
  		  	background-color: lavender;
			}

input[type=text], input[type=password] {
  										width: 100%;
  										padding: 15px;
  										margin: 5px 0 22px 0;
  										display: inline-block;
  										border: none;
  										background: lightgray;
										}

input[type=text]:focus, input[type=password]:focus {
  													background-color: whitesmoke;	
  													outline: none;
												   }

									  .registerbtn {
  													background-color: seashell;
  													color: black;
 													padding: 16px 20px;
													margin: 8px 0;
													border: none;
													cursor: pointer;
													width: 100%;
													opacity: 0.9;
												   }

							    .registerbtn:hover {
  													opacity: 2;
												   }

												 a {
													color: dodgerblue;
												    }

										   .signin {
													background-color: lavenderblush;
													text-align: center;
												    }
	</style>
</head>
	<body>

		<form action="/read.php">
		  <div class="container">
		    <h1 align="center">LOGIN</h1>
		    <hr>

		    <label for="email"><b>Email</b></label>
		    <input type="text" placeholder="Enter Email" id="email" required>

		    <label for="psw"><b>Password</b></label>
		    <input type="password" placeholder="Enter Password" id="psw" required>

		    <label for="psw-repeat"><b>Repeat Password</b></label>
		    <input type="password" placeholder="Repeat Password" id="psw-repeat" required>

		    <button type="submit" class="registerbtn">Register</button>
		  </div>
		  
		  <div class="container signin">
		    <p><a href="#">Sign in</a>.</p>
		  </div>
		</form>
	</body>
</head>
</html>