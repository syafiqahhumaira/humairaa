<?php 
require "read.php";

$id = $_GET['id'];
$sql = "DELETE FROM table_crud WHERE id = '$id'";
$execute = mysqli_query($koneksi, $sql);

	if($execute)
	{
	header("location:read.php");
	}

	else 
	{
	echo "FAILED !";
	}
	
 	?>